# RULES - project policies for reviewing the Arabic

1. Punctuation: ASCII `?` and `,` only (no Arabic question mark, comma or semicolon).
2. No diacritics (tashkeel) and no tatweel.
3. Correct orthography, including alef maqsura (ى) vs ya (ي).
4. Names only from `glossary.md`.
5. Tags and the line-break marker stay. `⏎` = one line break (byte 0x02), written ` ⏎ `. Tags are written as `<HH ..>` = the command byte plus its operand bytes in hex, exactly as stored (e.g. `<13 FA 00 64 00>`, `<09 DA>` = button icon). `<X nn>` = a raw font cell with no single-character meaning (e.g. `<X 5E>`, `<X 2E>` = tight full stop cell used in gumi).
6. Width limits: `width_pct` = widest line of the installed Arabic / widest line of the English, measured with the game font tables (same method as translationind.py). Rows above 130 are flagged `wide`; above 150 they usually overflow.
7. Flags are automatic and cheap: dblspace, space_before_punct, forbidden_char, latin:<letters> (Latin letters outside A H I M P S T W in a translated row), repeat_word, wide, same_as_en (row not translated, bytes equal the original).

## CSV conventions
- Encoding UTF-8 with BOM; columns bar,id,EN,AR,width_pct,flags; max 250 rows per part; order sys, tt, worlds, jm, title, gumi; no dedupe.
- AR is in LOGICAL (reading) order, decoded from the installed bytes (cells reversed back, Latin/digit runs kept left-to-right). Verified per bar: decode -> re-encode == installed bytes for every translated visible row.
- Lam-alef ligature cell 36 is shown as `لا` in the evt-atlas bars (tt and world bars); in sys, jm, title, gumi cell 36 is the Latin W.

## Presentation-form mapping (installed font cell -> base letter shown in AR)
| presentation form | base |
|---|---|
| U+FE80 ﺀ | ء |
| U+FE81 ﺁ | آ |
| U+FE82 ﺂ | آ |
| U+FE83 ﺃ | أ |
| U+FE84 ﺄ | أ |
| U+FE85 ﺅ | ؤ |
| U+FE86 ﺆ | ؤ |
| U+FE87 ﺇ | إ |
| U+FE88 ﺈ | إ |
| U+FE89 ﺉ | ئ |
| U+FE8A ﺊ | ئ |
| U+FE8B ﺋ | ئ |
| U+FE8C ﺌ | ئ |
| U+FE8D ﺍ | ا |
| U+FE8E ﺎ | ا |
| U+FE8F ﺏ | ب |
| U+FE90 ﺐ | ب |
| U+FE91 ﺑ | ب |
| U+FE92 ﺒ | ب |
| U+FE93 ﺓ | ة |
| U+FE94 ﺔ | ة |
| U+FE95 ﺕ | ت |
| U+FE96 ﺖ | ت |
| U+FE97 ﺗ | ت |
| U+FE98 ﺘ | ت |
| U+FE99 ﺙ | ث |
| U+FE9A ﺚ | ث |
| U+FE9B ﺛ | ث |
| U+FE9C ﺜ | ث |
| U+FE9D ﺝ | ج |
| U+FE9E ﺞ | ج |
| U+FE9F ﺟ | ج |
| U+FEA0 ﺠ | ج |
| U+FEA1 ﺡ | ح |
| U+FEA2 ﺢ | ح |
| U+FEA3 ﺣ | ح |
| U+FEA4 ﺤ | ح |
| U+FEA5 ﺥ | خ |
| U+FEA6 ﺦ | خ |
| U+FEA7 ﺧ | خ |
| U+FEA8 ﺨ | خ |
| U+FEA9 ﺩ | د |
| U+FEAA ﺪ | د |
| U+FEAB ﺫ | ذ |
| U+FEAC ﺬ | ذ |
| U+FEAD ﺭ | ر |
| U+FEAE ﺮ | ر |
| U+FEAF ﺯ | ز |
| U+FEB0 ﺰ | ز |
| U+FEB1 ﺱ | س |
| U+FEB2 ﺲ | س |
| U+FEB3 ﺳ | س |
| U+FEB4 ﺴ | س |
| U+FEB5 ﺵ | ش |
| U+FEB6 ﺶ | ش |
| U+FEB7 ﺷ | ش |
| U+FEB8 ﺸ | ش |
| U+FEB9 ﺹ | ص |
| U+FEBA ﺺ | ص |
| U+FEBB ﺻ | ص |
| U+FEBC ﺼ | ص |
| U+FEBD ﺽ | ض |
| U+FEBE ﺾ | ض |
| U+FEBF ﺿ | ض |
| U+FEC0 ﻀ | ض |
| U+FEC1 ﻁ | ط |
| U+FEC2 ﻂ | ط |
| U+FEC3 ﻃ | ط |
| U+FEC4 ﻄ | ط |
| U+FEC5 ﻅ | ظ |
| U+FEC6 ﻆ | ظ |
| U+FEC7 ﻇ | ظ |
| U+FEC8 ﻈ | ظ |
| U+FEC9 ﻉ | ع |
| U+FECA ﻊ | ع |
| U+FECB ﻋ | ع |
| U+FECC ﻌ | ع |
| U+FECD ﻍ | غ |
| U+FECE ﻎ | غ |
| U+FECF ﻏ | غ |
| U+FED0 ﻐ | غ |
| U+FED1 ﻑ | ف |
| U+FED2 ﻒ | ف |
| U+FED3 ﻓ | ف |
| U+FED4 ﻔ | ف |
| U+FED5 ﻕ | ق |
| U+FED6 ﻖ | ق |
| U+FED7 ﻗ | ق |
| U+FED8 ﻘ | ق |
| U+FED9 ﻙ | ك |
| U+FEDA ﻚ | ك |
| U+FEDB ﻛ | ك |
| U+FEDC ﻜ | ك |
| U+FEDD ﻝ | ل |
| U+FEDE ﻞ | ل |
| U+FEDF ﻟ | ل |
| U+FEE0 ﻠ | ل |
| U+FEE1 ﻡ | م |
| U+FEE2 ﻢ | م |
| U+FEE3 ﻣ | م |
| U+FEE4 ﻤ | م |
| U+FEE5 ﻥ | ن |
| U+FEE6 ﻦ | ن |
| U+FEE7 ﻧ | ن |
| U+FEE8 ﻨ | ن |
| U+FEE9 ﻩ | ه |
| U+FEEA ﻪ | ه |
| U+FEEB ﻫ | ه |
| U+FEEC ﻬ | ه |
| U+FEED ﻭ | و |
| U+FEEE ﻮ | و |
| U+FEEF ﻯ | ى |
| U+FEF0 ﻰ | ى |
| U+FEF1 ﻱ | ي |
| U+FEF2 ﻲ | ي |
| U+FEF3 ﻳ | ي |
| U+FEF4 ﻴ | ي |
| U+FEFB ﻻ (lam-alef, cell 36) | لا |
| U+FEFC ﻼ | لا |
