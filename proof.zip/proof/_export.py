"""PROOF-EXPORT-LITE: decode INSTALLED {mod}\\msg\\us bars -> verify decode->re-encode == bytes -> CSV parts.  Read-only on game files.
Port of Program.cs Shape / ToVisualOrder / EncodeMsg (see font-rtl/arabic/Program.cs 3108-3294)."""
import os, re, io, csv, struct, sys, shutil, collections
sys.stdout.reconfigure(encoding='utf-8')
R = 'C:/filessss/mewo/kh2fm-arabic/'
sys.path.insert(0, R + 'font-rtl/arabic/fonttest_tools')
import fixq_lib as L
L.SZ[0x0E] = 1
SZ = dict(L.SZ)
MOD, ORIG = L.MOD + 'msg/us/', L.ORIG
OUT = R + 'out/10_BUILDS/proof/'
ORDER = 'sys tt di es wm hb mu bb he dc ca al nm lk lm tr po wi eh jm title gumi'.split()
LIGBARS = set('tt di es wm hb mu bb he dc ca al nm lk lm tr po wi eh'.split())  # lam-alef ligature cell 36 (evt atlas); sys/jm/title/gumi: cell 36 = Latin W
NOLIG_TT = set()
for l in io.open(R + 'translation/noliga_ids.txt', encoding='utf-8'):
    t = l.split('#')[0].strip()
    if t.isdigit(): NOLIG_TT.add(int(t))
BOUND = (0x10, 0x14, 0x17)
LIG = 36
NL = ' \u23ce '

# ---------- maps
JOIN = {}
for c in 'بتثجحخسشصضطظعغفقكلمنهيئ': JOIN[c] = 'D'
for c in 'ادذرزوةأإآؤى': JOIN[c] = 'R'
JOIN['ء'] = 'U'
cell_ar, ar_enc = {}, {}
for l in io.open(R + 'font-rtl/arabic/allocation.tsv', encoding='utf-8').read().split('\n')[1:]:
    p = l.split('\t')
    if len(p) > 5 and p[4].isdigit():
        cell_ar[int(p[4])] = p[0]; ar_enc[(p[0], int(p[2]))] = int(p[4])
cell_ch, char_cell = {}, {}
for l in io.open(R + 'font-rtl/arabic/codemap.tsv', encoding='utf-8').read().split('\n')[1:]:
    p = l.split('\t')
    if len(p) > 10 and p[10] == 'GLYPH' and p[1].lstrip('-').isdigit() and len(p[5]) == 1:
        c = int(p[1])
        if c < 0: continue
        cell_ch[c] = p[5]
        if c not in cell_ar and p[5] not in char_cell: char_cell[p[5]] = c
cell_ch.pop(46, None); char_cell = {k: v for k, v in char_cell.items() if v != 46}   # cell 46 = tight full stop (AltPeriodCell, gumi only): kept as token <X 2E>


def msgs(b):
    off, ln = struct.unpack_from('<II', b, 24)
    m = b[off:off + ln]
    n = struct.unpack_from('<I', m, 4)[0]
    ids = [struct.unpack_from('<I', m, 8 + i * 8)[0] for i in range(n)]
    of = [struct.unpack_from('<I', m, 12 + i * 8)[0] for i in range(n)]
    return {ids[i]: m[of[i]:(of[i + 1] if i + 1 < n else len(m))] for i in range(n)}


# ---------- reorder (port of ReverseRunOrder / ToVisualOrder); items = (char, isArabic); sentinels E000+k
def rro(s, seg, icons):
    if not any(s[k][1] for k in seg): return seg
    runs = []
    for k in seg:
        isAr = s[k][1]; isSep = s[k][0] in ' \n'
        prevSep = bool(runs) and s[runs[-1][0]][0] in ' \n'
        isIcon = s[k][0] in icons; prevIcon = bool(runs) and s[runs[-1][0]][0] in icons
        if not runs or isSep or prevSep or isIcon != prevIcon or s[runs[-1][0]][1] != isAr: runs.append([])
        runs[-1].append(k)
    vis = []
    for r in reversed(runs):
        if s[r[0]][1]: r = r[::-1]
        vis += r
    return vis


def visual_order(s, hard, icons):
    res, seg = [], []
    for i, (c, a) in enumerate(s):
        if c == '\n' or c in hard:
            res += rro(s, seg, icons); res.append(i); seg = []
        else: seg.append(i)
    return res + rro(s, seg, icons)


# ---------- decode
def parse(m):
    """-> list of items ('c',cell)|('sp',)|('nl',)|('t',bytes); raises on bad structure; returns (items, endpos)"""
    it, i = [], 0
    while True:
        if i >= len(m): raise ValueError('no End 0x00')
        b = m[i]
        if b == 0: break
        if b == 1: it.append(('sp',))
        elif b == 2: it.append(('nl',))
        elif b < 0x20:
            if b not in SZ: raise ValueError('unknown cmd %02X' % b)
            n = SZ[b]
            if i + n >= len(m): raise ValueError('truncated cmd')
            it.append(('t', bytes(m[i:i + n + 1]))); i += n
        else: it.append(('c', b - 0x20))
        i += 1
    if any(m[i:]): raise ValueError('non-zero after End')
    return it, i


def tag_tok(b): return '<' + ' '.join('%02X' % x for x in b) + '>'


def decode(m, arabic, lig):
    items, _ = parse(m)
    sent, flat = [], []
    for x in items:
        if x[0] == 'sp': flat.append((' ', False))
        elif x[0] == 'nl': flat.append(('\n', False))
        elif x[0] == 't':
            flat.append((chr(0xE000 + len(sent)), False)); sent.append(tag_tok(x[1]) + '')
        else:
            c = x[1]
            if arabic and c in cell_ar: flat.append((cell_ar[c], True))
            elif arabic and lig and c == LIG: flat.append(('\u0627', True)); flat.append(('\u0644', True))
            elif c in cell_ch: flat.append((cell_ch[c], False))
            else: flat.append((chr(0xE000 + len(sent)), False)); sent.append('<X %02X>' % c)
    hard, icons = set(), set()
    k = 0
    for x in items:
        if x[0] == 't' or False: pass
    # sentinel kinds: rebuild list of kinds in sentinel order
    kinds = []
    for x in items:
        if x[0] == 't': kinds.append(x[1][0])
        elif x[0] == 'c' and not ((arabic and x[1] in cell_ar) or (arabic and lig and x[1] == LIG) or x[1] in cell_ch): kinds.append(None)
    for k, kd in enumerate(kinds):
        if kd in BOUND: hard.add(chr(0xE000 + k))
        if kd == 9: icons.add(chr(0xE000 + k))
    order = visual_order(flat, hard, icons) if arabic else range(len(flat))
    out = []
    for k in order:
        c = flat[k][0]
        if c == '\n': out.append(NL)
        elif 0xE000 <= ord(c) <= 0xF8FF: out.append(sent[ord(c) - 0xE000])
        else: out.append(c)
    return ''.join(out)


# ---------- encode (port of Shape + EncodeMsg)
def encode(s, lig):
    sent, flat = [], []
    s = s.replace(NL, '\n')
    i = 0
    while i < len(s):
        mt = re.match(r'<X ([0-9A-F]{2})>', s[i:])
        mt2 = re.match(r'<((?:[0-9A-F]{2})(?: [0-9A-F]{2})*)>', s[i:])
        if s[i] == '<' and mt:
            flat.append(chr(0xE000 + len(sent))); sent.append(bytes([int(mt.group(1), 16) + 0x20])); i += mt.end()
        elif s[i] == '<' and mt2:
            raw = bytes(int(x, 16) for x in mt2.group(1).split(' '))
            if raw[0] in SZ and len(raw) == SZ[raw[0]] + 1:
                flat.append(chr(0xE000 + len(sent))); sent.append(raw); i += mt2.end()
            else: flat.append(s[i]); i += 1
        else: flat.append(s[i]); i += 1
    n = len(flat)
    isA = [c in JOIN for c in flat]
    shaped = []
    for i, c in enumerate(flat):
        if not isA[i]: shaped.append((c, -1)); continue
        jp = i > 0 and isA[i - 1] and JOIN[flat[i - 1]] == 'D' and JOIN[c] != 'U'
        jn = i + 1 < n and isA[i + 1] and JOIN[flat[i + 1]] != 'U' and JOIN[c] == 'D'
        jp2 = JOIN[c] != 'U' and jp; jn2 = JOIN[c] == 'D' and jn
        f = 3 if jp2 and jn2 else 1 if jp2 else 2 if jn2 else 0
        shaped.append((c, f))
    hard = {chr(0xE000 + k) for k, r in enumerate(sent) if r[0] in BOUND and r[0] < 0x20}
    icons = {chr(0xE000 + k) for k, r in enumerate(sent) if r[0] == 9}
    order = visual_order([(c, f >= 0) for c, f in shaped], hard, icons)
    vis = [shaped[k] for k in order]
    res = bytearray(); vi = 0
    while vi < len(vis):
        c, f = vis[vi]
        if lig and c == '\u0627' and f == 1 and vi + 1 < len(vis) and vis[vi + 1] == ('\u0644', 2):
            res.append(LIG + 0x20); vi += 2; continue
        if 0xE000 <= ord(c) <= 0xF8FF: res += sent[ord(c) - 0xE000]
        elif f >= 0: res.append(ar_enc[(c, f)] + 0x20)
        elif c == ' ': res.append(1)
        elif c == '\n': res.append(2)
        else: res.append(char_cell[c] + 0x20)
        vi += 1
    return bytes(res)


def padded(m):
    _, e = parse(m); return m[:e]


# ---------- checks
FORB = re.compile('[\u061f\u060c\u061b\u064b-\u0652\u0670\u0640]')
OKLAT = set('AHIMPSTW')
TAG = re.compile(r'<[0-9A-FX][^>]*>')
ARB = lambda c: '\u0600' <= c <= '\u06ff'


def flags(ar, en, changed, wp):
    f = []
    lines = [x for x in ar.split(NL)]
    plain = TAG.sub('\x00', ar)
    if '  ' in plain.replace(NL, '\n').replace('\x00', ''): pass
    if any('  ' in ln for ln in lines): f.append('dblspace')
    if any(re.search(r' [,.?!:]', ln) for ln in lines): f.append('space_before_punct')
    if FORB.search(ar): f.append('forbidden_char')
    if changed:
        bad = {c for c in TAG.sub('', ar) if c.isascii() and c.isalpha() and c not in OKLAT}
        if bad: f.append('latin:' + ''.join(sorted(bad)))
        for ln in lines:
            w = TAG.sub(' ', ln).split()
            if any(a == b and len(a) > 1 for a, b in zip(w, w[1:])): f.append('repeat_word'); break
        if wp is not None and wp > 130: f.append('wide')
    else: f.append('same_as_en')
    return ';'.join(f)


def run():
    rep = {}
    rows_total = 0
    metric = {}
    for l in open(R + 'translation/metric.tsv', encoding='utf-8').read().split('\n')[1:]:
        p = l.split('\t')
        if len(p) > 3 and p[0]: metric[p[0]] = int(p[2])
    for bar in ORDER:
        info = dict(rows=0, files=0, mism=[], err=[], flagged=0, vis_all=0)
        rep[bar] = info
        a = msgs(open(MOD + bar + '.bar', 'rb').read()); o = msgs(open(ORIG + bar + '.bar', 'rb').read())
        atlas = 'sys' if bar == 'sys' else 'evt'
        new, ret = L.lists(atlas)
        rows = []
        for i in sorted(o):
            if i not in a: continue
            ob, ib = o[i], a[i]
            if not any(ob): continue
            try: en = decode(ob, False, False)
            except Exception as e:
                info['err'].append((i, 'EN ' + str(e))); continue
            if not re.search('[A-Za-z]', TAG.sub('', en)): continue
            info['vis_all'] += 1
            changed = ib != ob
            lig = bar in LIGBARS and i not in NOLIG_TT
            try:
                ar = decode(ib, changed, lig)
                if changed and encode(ar, lig) != padded(ib):
                    # retry the other ligature setting only to report which; mismatch stands
                    info['mism'].append(i); continue
            except Exception as e:
                info['err'].append((i, str(e)[:60])); continue
            e_w = L.maxw(ob, ret)
            wp = round(100 * L.maxw(ib, new) / e_w) if changed and e_w else None
            fl = flags(ar, en, changed, wp)
            rows.append((bar, i, en, ar, '' if wp is None else wp, fl))
        if info['mism'] or info['err']:
            info['stopped'] = True
            continue
        info['rows'] = len(rows); rows_total += len(rows)
        info['flagged'] = sum(1 for r in rows if r[5] and r[5] != 'same_as_en' and not r[5].startswith('same_as_en'))
        info['untrans'] = sum(1 for r in rows if r[5] == 'same_as_en')
        for p in range(0, len(rows), 250):
            fn = '%s_part%02d.csv' % (bar, p // 250 + 1)
            with io.open(OUT + fn, 'w', encoding='utf-8-sig', newline='') as f:
                w = csv.writer(f); w.writerow(['bar', 'id', 'EN', 'AR', 'width_pct', 'flags'])
                w.writerows(rows[p:p + 250])
            info['files'] += 1
    return rep, metric, rows_total


if __name__ == '__main__':
    rep, metric, tot = run()
    for b, i in rep.items():
        print(b, 'rows', i['rows'], 'vis', i['vis_all'], 'metric', metric.get(b), 'mism', len(i['mism']), 'err', len(i['err']), 'flagged', i['flagged'], i['mism'][:5], i['err'][:3])
    print('TOTAL', tot, 'metric', sum(metric.values()))
